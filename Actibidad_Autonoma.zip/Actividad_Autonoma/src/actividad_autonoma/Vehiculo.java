package actividad_autonoma;
import java.util.*;

public class Vehiculo {
    String marca;
    String modelo;
    int año;

    public Vehiculo(String marca, String modelo, int año) {
        this.marca = marca;
        this.modelo = modelo;
        this.año = año;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public void mostrarInformacion() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Año: " + año);
    }

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        ArrayList<Vehiculo> lista = new ArrayList<>();
        int opcion;

        do {
            System.out.println("OPCIONES");
            System.out.println("1: Registrar automovil");
            System.out.println("2: Registrar motocicleta");
            System.out.println("3: Mostrar información");
            System.out.println("4: Salir");
            System.out.print("Selecciona una opcion: ");
            opcion = leer.nextInt();
            leer.nextLine();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese los datos del automovil");
                    System.out.print("Ingrese la marca del auto: ");
                    String marcaAuto = leer.nextLine();

                    System.out.print("Ingrese el modelo del automovil: ");
                    String modeloAuto = leer.nextLine();

                    System.out.print("Ingrese el año del automovil: ");
                    int añoAuto = leer.nextInt();

                    System.out.print("Ingrese el número de puertas: ");
                    int puertas = leer.nextInt();

                    Automovil auto = new Automovil(puertas, marcaAuto, modeloAuto, añoAuto);
                    lista.add(auto);

                    System.out.println("Automovil registrado.");
                    break;

                case 2:
                    System.out.println("Ingrese los datos de la motocicleta");
                    System.out.print("Ingrese la marca de la motocicleta: ");
                    String marcaMoto = leer.nextLine();

                    System.out.print("Ingrese el modelo de la motocicleta: ");
                    String modeloMoto = leer.nextLine();

                    System.out.print("Ingrese el año de la motocicleta: ");
                    int añoMoto = leer.nextInt();

                    System.out.print("Ingrese el cilindraje: ");
                    int cilindraje = leer.nextInt();

                    Motocicleta moto = new Motocicleta(cilindraje, marcaMoto, modeloMoto, añoMoto);
                    lista.add(moto);

                    System.out.println("Motocicleta registrada.");
                    break;

                case 3:
                    System.out.println("Información de vehículos registrados:");
                    for (Vehiculo vehiculo : lista) {
                        vehiculo.mostrarInformacion();
                        System.out.println("------------------------");
                    }
                    break;
            }
        } while (opcion != 4);
    }
}
       
        
      

        
    

    
    
    
    



package actividad_autonoma;


public class Motocicleta extends Vehiculo {
    
    int cilindraje;

    public Motocicleta(int cilindraje, String marca, String modelo, int año) {
        super(marca, modelo, año);
        this.cilindraje = cilindraje;
    }

    public int getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Cilindraje "+ cilindraje);
    }
    
    
}


package actividad_autonoma;


public class Automovil extends Vehiculo {
    
    int puertas;

    public Automovil(int puertas, String marca, String modelo, int año) {
        super(marca, modelo, año);
        
        this.puertas = puertas;
    }

    

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        
        System.out.println("Puertas "+ puertas);
    }
    
    
}

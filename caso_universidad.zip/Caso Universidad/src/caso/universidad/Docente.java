
package caso.universidad;


public class Docente {
    String escalafon;

    public Docente(String escalafon) {
        this.escalafon = escalafon;
    }

    public String getEscalafon() {
        return escalafon;
    }

    public void setEscalafon(String escalafon) {
        this.escalafon = escalafon;
    }
    
     void consultarInfoPersonal() {
    
        }
}

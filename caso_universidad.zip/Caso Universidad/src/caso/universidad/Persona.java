package caso.universidad;
import java.util.*;


public class Persona {

    public static void main(String[] args) {
        
        Scanner leer = new Scanner(System.in);
        ArrayList<Personas> Lista = new ArrayList<>();
        int opcion;

        do {
            System.out.println("OPCIONES");
            System.out.println("1: Inscribirse");
            System.out.println("2: Consultar informacion personal");
            System.out.println("3: Pagar Matricula");
       
            System.out.println("5. Salir");
            System.out.print("Selecciona una opcion: ");
            opcion = leer.nextInt();
            leer.nextLine(); // Consumir el salto de línea pendiente

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese sus datos");
                    System.out.print("Ingrese su numero de identidad: ");
                    int NroId = leer.nextInt();
                    leer.nextLine(); // Consumir el salto de línea pendiente

                    System.out.print("Ingrese su tipo de documento: ");
                    String TipoID = leer.nextLine();

                    System.out.print("Ingrese sus nombres: ");
                    String nombres = leer.nextLine();

                    System.out.print("Ingrese sus apellidos: ");
                    String apellidos = leer.nextLine();

                    System.out.print("Ingrese su direccion: ");
                    int direccion = leer.nextInt();

                    Personas persona = new Personas(NroId, TipoID, nombres, apellidos, direccion);
                    Lista.add(persona);

                    System.out.println("Persona registrada.");
                    break;

                case 2:
                    for (int i = 0; i < Lista.size(); i++) {
                        System.out.println("Datos del estudiante " + (i + 1));
                        System.out.println("ID: " + Lista.get(i).getNroId());
                        System.out.println("Tipo de documento : " + Lista.get(i).getTipoID());
                        System.out.println("Nombres: " + Lista.get(i).getNombres());
                        System.out.println("Apellidos: " + Lista.get(i).getApellidos());
                        System.out.println("Direccion: " + Lista.get(i).getDireccion());
                        System.out.println();
                    }
                    break;

                case 3:
                    Estudiante.pagarMatricula();
                    break;

                
            }
        } while (opcion != 5);
    }
}

                        
       
   

    
   
    
      

  

    
    

    
    


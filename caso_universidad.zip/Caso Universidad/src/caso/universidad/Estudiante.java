
package caso.universidad;

public class Estudiante extends Docente {
    
    String codigo;

    public Estudiante(String codigo, String escalafon) {
        super(escalafon);
        this.codigo = codigo;
    }

    
    public static boolean pagarMatricula(){
        System.out.println("Matricula pagada");
        return false;
    }
    
    @Override
        void consultarInfoPersonal() {
        super.consultarInfoPersonal(); 
    }
    
    
    
}

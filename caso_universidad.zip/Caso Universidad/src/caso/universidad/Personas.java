package caso.universidad;


public class Personas  {
    int NroId;
    String TipoID;
    String nombres;
    String apellidos;
    int direccion;

    public Personas(int NroId, String tipoID, String nombres, String apellidos, int direccion) {
        this.NroId = NroId;
        this.TipoID = tipoID;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
    }

    

    public int getNroId() {
        return NroId;
    }

    public void setNroId(int NroId) {
        this.NroId = NroId;
    }

    public String getTipoID() {
        return TipoID;
    }

    public void setTipoID(String tipoID) {
        this.TipoID = tipoID;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getDireccion() {
        return direccion;
    }

    public void setDireccion(int direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Personas{" + "NroId=" + NroId + ", tipoID=" + TipoID + ", nombres=" + nombres + ", apellidos=" + apellidos + ", direccion=" + direccion + '}';
    }

    
    
   
    
    
}

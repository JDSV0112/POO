
package caso.universidad;


public class Administrativo extends Estudiante {
   int salario;

    public Administrativo(int salario, String codigo, String escalafon) {
        super(codigo, escalafon);
        this.salario = salario;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    
    
    
    @Override
        void consultarInfoPersonal() {
        super.consultarInfoPersonal();
    }
    
    
    
}

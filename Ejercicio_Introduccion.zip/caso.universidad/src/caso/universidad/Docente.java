
package caso.universidad;

class Docente extends Personas {
    private String escalafon;

    public Docente(String escalafon, int NroId, String tipoID, String nombres, String apellidos, String direccion) {
        super(NroId, tipoID, nombres, apellidos, direccion);
        this.escalafon = escalafon;
    }

    public String getEscalafon() {
        return escalafon;
    }

    public void setEscalafon(String escalafon) {
        this.escalafon = escalafon;
    }

    @Override
    public void consultarInfoPersonal() {
        super.consultarInfoPersonal();
        System.out.println("Escalafón: " + escalafon);
    }
}

package caso.universidad;

class Administrativo extends Estudiante {
    private int salario;

    public Administrativo(int salario, String codigo, int NroId, String tipoID, String nombres, String apellidos, String direccion) {
        super(codigo, NroId, tipoID, nombres, apellidos, direccion);
        this.salario = salario;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    @Override
    public void consultarInfoPersonal() {
        super.consultarInfoPersonal();
        System.out.println("Salario: $" + salario);
    }
}
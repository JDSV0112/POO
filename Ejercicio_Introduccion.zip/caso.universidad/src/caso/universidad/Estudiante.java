
package caso.universidad;

class Estudiante extends Personas {
    private String codigo;

    public Estudiante(String codigo, int NroId, String tipoID, String nombres, String apellidos, String direccion) {
        super(NroId, tipoID, nombres, apellidos, direccion);
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public boolean pagarMatricula() {
        System.out.println("Matrícula pagada por el estudiante " + codigo);
        return true;
    }

    @Override
    public void consultarInfoPersonal() {
        super.consultarInfoPersonal();
        System.out.println("Código de estudiante: " + codigo);
    }
}
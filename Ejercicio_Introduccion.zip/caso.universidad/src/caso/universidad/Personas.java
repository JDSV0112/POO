
package caso.universidad;


public class Personas {
    private int NroId;
    private String tipoID;
    private String nombres;
    private String apellidos;
    private String direccion;

    public Personas(int NroId, String tipoID, String nombres, String apellidos, String direccion) {
        this.NroId = NroId;
        this.tipoID = tipoID;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.direccion = direccion;
    }

    public int getNroId() {
        return NroId;
    }

    public void setNroId(int NroId) {
        this.NroId = NroId;
    }

    public String getTipoID() {
        return tipoID;
    }

    public void setTipoID(String tipoID) {
        this.tipoID = tipoID;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public void consultarInfoPersonal() {
        
        System.out.println("Información personal de la persona:");
        System.out.println("NroId: " + NroId);
        System.out.println("Tipo de ID: " + tipoID);
        System.out.println("Nombres: " + nombres);
        System.out.println("Apellidos: " + apellidos);
        System.out.println("Dirección: " + direccion);
    }
    @Override
    public String toString() {
        return "Personas{" +
                "NroId=" + NroId +
                ", tipoID='" + tipoID + '\'' +
                ", nombres='" + nombres + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", direccion='" + direccion + '\'' +
                '}';
    }
}

package caso.universidad;

import java.util.ArrayList;
import java.util.Scanner;

public class Universidad {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        ArrayList<Personas> listaPersonas = new ArrayList<>();
        int opcion;

        do {
            System.out.println("OPCIONES");
            System.out.println("1: Inscribirse como estudiante");
            System.out.println("2: Inscribirse como docente");
            System.out.println("3: Inscribirse como administrativo");
            System.out.println("4: Consultar informacion personal");
            System.out.println("5: Pagar Matricula");
            System.out.println("6: Salir");
            System.out.print("Selecciona una opcion: ");
            opcion = leer.nextInt();
            leer.nextLine(); 
            switch (opcion) {
                case 1:
                    System.out.println("Ingrese sus datos como estudiante");
                    System.out.print("Ingrese su numero de identidad: ");
                    int nroIdEstudiante = leer.nextInt();
                    leer.nextLine(); 

                    System.out.print("Ingrese su tipo de documento: ");
                    String tipoIdEstudiante = leer.nextLine();

                    System.out.print("Ingrese sus nombres: ");
                    String nombresEstudiante = leer.nextLine();

                    System.out.print("Ingrese sus apellidos: ");
                    String apellidosEstudiante = leer.nextLine();

                    System.out.print("Ingrese su dirección: ");
                    String direccionEstudiante = leer.nextLine();

                    System.out.print("Ingrese su código de estudiante: ");
                    String codigoEstudiante = leer.nextLine();

                    Estudiante estudiante = new Estudiante(codigoEstudiante, nroIdEstudiante, tipoIdEstudiante,
                            nombresEstudiante, apellidosEstudiante, direccionEstudiante);
                    listaPersonas.add(estudiante);

                    System.out.println("Estudiante registrado.");
                    break;

                case 2:
                    System.out.println("Ingrese sus datos como docente");
                    System.out.print("Ingrese su número de identidad: ");
                    int nroIdDocente = leer.nextInt();
                    leer.nextLine(); 

                    System.out.print("Ingrese su tipo de documento: ");
                    String tipoIdDocente = leer.nextLine();

                    System.out.print("Ingrese sus nombres: ");
                    String nombresDocente = leer.nextLine();

                    System.out.print("Ingrese sus apellidos: ");
                    String apellidosDocente = leer.nextLine();

                    System.out.print("Ingrese su dirección: ");
                    String direccionDocente = leer.nextLine();

                    System.out.print("Ingrese su escalafón: ");
                    String escalafonDocente = leer.nextLine();

                    Docente docente = new Docente(escalafonDocente, nroIdDocente, tipoIdDocente,
                            nombresDocente, apellidosDocente, direccionDocente);
                    listaPersonas.add(docente);

                    System.out.println("Docente registrado.");
                    break;

                case 3:
                    System.out.println("Ingrese sus datos como administrativo");
                    System.out.print("Ingrese su número de identidad: ");
                    int nroIdAdministrativo = leer.nextInt();
                    leer.nextLine(); 

                    System.out.print("Ingrese su tipo de documento: ");
                    String tipoIdAdministrativo = leer.nextLine();

                    System.out.print("Ingrese sus nombres: ");
                    String nombresAdministrativo = leer.nextLine();

                    System.out.print("Ingrese sus apellidos: ");
                    String apellidosAdministrativo = leer.nextLine();

                    System.out.print("Ingrese su dirección: ");
                    String direccionAdministrativo = leer.nextLine();

                    System.out.print("Ingrese su salario: ");
                    int salarioAdministrativo = leer.nextInt();

                    System.out.print("Ingrese su código de administrativo: ");
                    String codigoAdministrativo = leer.nextLine();

                    Administrativo administrativo = new Administrativo(salarioAdministrativo, codigoAdministrativo,
                            nroIdAdministrativo, tipoIdAdministrativo, nombresAdministrativo,
                            apellidosAdministrativo, direccionAdministrativo);
                    listaPersonas.add(administrativo);

                    System.out.println("Administrativo registrado.");
                    break;

                case 4:
                  
                    System.out.println("Informacion personal de las personas:");
                    for (Personas persona : listaPersonas) {
                        persona.consultarInfoPersonal();
                        System.out.println();
                    }
                    break;

                case 5:
                    // Pagar Matrícula
                    System.out.print("Ingrese el codigo del estudiante para pagar matrícula: ");
                    String codigoMatricula = leer.nextLine();
                    for (Personas persona : listaPersonas) {
                        if (persona instanceof Estudiante) {
                            Estudiante est = (Estudiante) persona;
                            if (est.getCodigo().equals(codigoMatricula)) {
                                est.pagarMatricula();
                                break;
                            }
                        }
                    }
                    break;
            }
        } while (opcion != 6);
    }
}

